
const initialState = {
    isLoading: false
}

export const loginReducer = (state = initialState, action) => {
    return state;
};