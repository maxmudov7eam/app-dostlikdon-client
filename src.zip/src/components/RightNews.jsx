import React from 'react'

const RightNews = () => {
    return (
        <div className='rightNews'>
            <div class="right-card">
                            <h1>
                                Media
                            </h1>
                            <div class="card p-0 border-0">
                                <div class="card-body p-0 border-0 ">
                                    <div class="d-flex align-items-center">
                                        <div class="d-flex align-items-center">
                                            <span class="pr-2 "><img src="assets/icon/bag.svg" alt=""/></span>
                                            <a href="#">16:48 / 12.11.20</a>
                                        </div>
                                        <p class="">Foto galereya</p>
                                    </div>
                                    <h2>"DO`STLIKDONMAXSULOTLARI" 
                                        AJ boshqaruv raisi</h2>
                                </div>
                            </div>
                            <div class="line"></div>
                            <div class="card p-0 border-0">
                                <div class="card-body p-0 border-0 ">
                                    <div class="d-flex align-items-center">
                                        <div class="d-flex align-items-center">
                                            <span class="pr-2 "><img src="assets/icon/bag.svg" alt=""/></span>
                                            <a href="#">16:48 / 12.11.20</a>
                                        </div>
                                        <p class="">Foto galereya</p>
                                    </div>
                                    <h2>"DO`STLIKDONMAXSULOTLARI" 
                                        AJ boshqaruv raisi</h2>
                                </div>
                            </div>
                            <div class="line"></div>
                            <div class="card p-0 border-0">
                                <div class="card-body p-0 border-0 ">
                                    <div class="d-flex align-items-center">
                                        <div class="d-flex align-items-center">
                                            <span class="pr-2 "><img src="assets/icon/bag.svg" alt=""/></span>
                                            <a href="#">16:48 / 12.11.20</a>
                                        </div>
                                        <p class="">Foto galereya</p>
                                    </div>
                                    <h2>"DO`STLIKDONMAXSULOTLARI" 
                                        AJ boshqaruv raisi</h2>
                                </div>
                            </div>
                            <div class="line"></div>
                            <div class="card p-0 border-0">
                                <div class="card-body p-0 border-0 ">
                                    <div class="d-flex align-items-center">
                                        <div class="d-flex align-items-center">
                                            <span class="pr-2 "><img src="assets/icon/bag.svg" alt=""/></span>
                                            <a href="#">16:48 / 12.11.20</a>
                                        </div>
                                        <p class="">Foto galereya</p>
                                    </div>
                                    <h2>"DO`STLIKDONMAXSULOTLARI" 
                                        AJ boshqaruv raisi</h2>
                                </div>
                            </div>
                        </div>
        </div>
    )
}

export default RightNews
